package CopaDelRey;

public class FormatoFormacionException extends Exception {
    public FormatoFormacionException(String message) {
        super(message);
    }
}
