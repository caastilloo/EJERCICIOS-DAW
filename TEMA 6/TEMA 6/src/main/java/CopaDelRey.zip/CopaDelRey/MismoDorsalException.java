package CopaDelRey;

public class MismoDorsalException extends Exception {

    public MismoDorsalException(String message) {
        super(message);
    }

}
