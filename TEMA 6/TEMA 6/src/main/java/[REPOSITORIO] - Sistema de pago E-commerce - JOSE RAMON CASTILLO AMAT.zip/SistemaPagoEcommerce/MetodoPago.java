package SistemaPagoEcommerce;

public abstract class MetodoPago {

    public abstract void procesarPago(double importe);
}
