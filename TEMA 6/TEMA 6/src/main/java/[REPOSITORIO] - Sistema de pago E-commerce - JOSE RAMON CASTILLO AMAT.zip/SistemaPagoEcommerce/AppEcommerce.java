package SistemaPagoEcommerce;

public class AppEcommerce {

    static void main() {

        Tienda.iniciarPago();

    }
}
